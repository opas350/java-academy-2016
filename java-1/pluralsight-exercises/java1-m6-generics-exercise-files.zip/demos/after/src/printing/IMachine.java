package printing;

public interface IMachine 
{
	public void TurnOn();
	public void TurnOff();
	public boolean isOn();
}
