package printing;

public static class PrinterMaker {

}
