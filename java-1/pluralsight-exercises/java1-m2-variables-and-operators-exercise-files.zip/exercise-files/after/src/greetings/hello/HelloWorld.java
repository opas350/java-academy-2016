package greetings.hello;

public class HelloWorld {

	public static void main(String[] args)
	{
		System.out.println("Hello World");
		
		int[] numbers = new int[10];
		
		numbers[0] = 5;
		numbers[1] = 8;
		
		System.out.println(numbers[2]);
		
		
	}
}
