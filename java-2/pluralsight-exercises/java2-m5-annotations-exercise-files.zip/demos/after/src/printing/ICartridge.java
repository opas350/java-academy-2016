package printing;

public interface ICartridge 
{
	public String getFillPercentage();
	public String printColor();
}
