package printing;

public class Page 
{
	private String printedText;
	
	public Page(String text)
	{
		printedText = text;
	}
	
	public String getText()
	{
		return printedText;
	}
	
}
